document.addEventListener("DOMContentLoaded", function(){
  // live client-side search (filters already rendered product cards)
  const live = document.getElementById("liveSearch");
  if(live){
    live.addEventListener("input", function(){
      const q = this.value.trim().toLowerCase();
      document.querySelectorAll(".product-card").forEach(card=>{
        const name = card.getAttribute("data-name") || card.querySelector("h3").textContent.toLowerCase();
        if(!q || name.includes(q)) card.style.display = "";
        else card.style.display = "none";
      });
    });
  }
});
